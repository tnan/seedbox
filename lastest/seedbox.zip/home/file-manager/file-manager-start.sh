#!/bin/bash
/home/file-manager/filebrowser -a 0.0.0.0 -p 8081 -r /var/www/html/download/ -d /home/file-manager/filebrowser.db
