self.addEventListener('install', () => {}), self.addEventListener('fetch', () => {})
