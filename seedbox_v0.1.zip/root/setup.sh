#!/bin/bash
apt update
DEBIAN_FRONTEND=noninteractive apt install php -y
DEBIAN_FRONTEND=noninteractive apt install software-properties-common -y
add-apt-repository ppa:qbittorrent-team/qbittorrent-stable -y
apt update
DEBIAN_FRONTEND=noninteractive apt install qbittorrent-nox -y

adduser --system --group torrent-downloader
gpasswd -a torrent-downloader www-data
gpasswd -a www-data torrent-downloader

echo "[Unit]" > /etc/systemd/system/torrent-downloader.service
echo "Description=Torrent Downloader" >> /etc/systemd/system/torrent-downloader.service
echo "" >> /etc/systemd/system/torrent-downloader.service
echo "[Service]" >> /etc/systemd/system/torrent-downloader.service
echo "User=torrent-downloader" >> /etc/systemd/system/torrent-downloader.service
echo "Group=www-data" >> /etc/systemd/system/torrent-downloader.service
echo "UMask=002" >> /etc/systemd/system/torrent-downloader.service
echo "ExecStart=/usr/bin/qbittorrent-nox" >> /etc/systemd/system/torrent-downloader.service
echo "" >> /etc/systemd/system/torrent-downloader.service
echo "[Install]" >> /etc/systemd/system/torrent-downloader.service
echo "WantedBy=multi-user.target" >> /etc/systemd/system/torrent-downloader.service


systemctl daemon-reload
systemctl enable torrent-downloader
systemctl start torrent-downloader

adduser --system --group file-manager
gpasswd -a file-manager www-data
gpasswd -a www-data file-manager

echo "[Unit]" > /etc/systemd/system/file-manager.service
echo "Description=File Manager" >> /etc/systemd/system/file-manager.service
echo "" >> /etc/systemd/system/file-manager.service
echo "[Service]" >> /etc/systemd/system/file-manager.service
echo "User=file-manager" >> /etc/systemd/system/file-manager.service
echo "Group=www-data" >> /etc/systemd/system/file-manager.service
echo "UMask=002" >> /etc/systemd/system/file-manager.service
echo "ExecStart=/home/file-manager/file-manager-start.sh" >> /etc/systemd/system/file-manager.service
echo "" >> /etc/systemd/system/file-manager.service
echo "[Install]" >> /etc/systemd/system/file-manager.service
echo "WantedBy=multi-user.target" >> /etc/systemd/system/file-manager.service

systemctl daemon-reload
systemctl enable file-manager
systemctl start file-manager

chown -R www-data:www-data /var/www/html/
chmod -R 777 /var/www/html/